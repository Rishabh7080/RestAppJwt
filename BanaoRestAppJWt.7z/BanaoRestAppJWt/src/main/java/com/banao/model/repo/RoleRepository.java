package com.banao.model.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.banao.model.Role;

public interface RoleRepository extends JpaRepository<Role, Integer> {

}
