package com.banao.model.service;

import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Service;

import com.banao.model.User;
import com.banao.model.UserRole;

@Service
public interface UserService {

	//for Create User 
	
	public User createUSer( User user,Set<UserRole> userRoles) throws Exception;

	public User getuser(String username);

	public void deleteUserByID(Integer id);
	//<link rel="stylesheet" href="dist/css/bootstrap-grid.min.css" />

	public List<User> finallAll();
		
	
}